drop sequence board_seq;
drop table board;

create sequence board_seq
    start with 1
    maxvalue 99999
    increment by 1
    nocache
    nocycle;

create table board (
    idx         number              default board_seq.nextval primary key,
    nickName    varchar2(100)       unique not null,   
    title       varchar2(100)       not null,
    content     varchar2(1000)      not null,
    writeDate        date                default sysdate
);

insert into board (nickName, title, content) values ('test1', 'test title1', 'test content1');
insert into board (nickName, title, content) values ('test2', 'test title2', 'test content2');

commit;

select * from board;

update board set title = 'update title2' where idx=2;

delete from board where idx=2;

commit;

select * from board where title like '%t%';
